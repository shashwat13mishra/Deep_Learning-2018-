
# coding: utf-8

# In[35]:


'''
Author: Shashwat Mishra
Using checkpointing in Tensorflow
'''
import dataloader
import tensorflow as tf
import numpy as np
import random
from sklearn import linear_model
import sys


tf.set_random_seed(123)  # reproducibility


# In[36]:


loader=dataloader.DataLoader()
images,labels=loader.load_data()

#mnist = tf.contrib.learn.datasets.load_dataset("mnist")
train_data = images  # Returns np.array
train_labels = np.eye(10)[np.asarray(labels, dtype=np.int32)]
loader=dataloader.DataLoader()
images,labels=loader.load_data('test')
test_data = images  # Returns np.array
test_labels = np.eye(10)[np.asarray(labels, dtype=np.int32)]
#print train_data.shape
val_data=train_data[40000:60000]
train_data=train_data[0:40000]

#print val_data
val_labels=train_labels[40000:60000]
train_labels=train_labels[0:40000]


# In[37]:


narg=len(sys.argv)
s=(sys.argv)
mode=s[1][2:]
if mode=='train':
    mode=1
elif mode=='test':
    mode=2
elif mode=='layer=1':
    mode=3
elif mode=='layer=2':
    mode=4
elif mode=='layer=3':
    mode=5
print 'Running in Mode : ' + str(mode)



# In[38]:


#train_data, val_data, train_labels, val_labels = train_test_split(train_data, train_labels, test_size=0.1, random_state=123)

learning_rate = 0.01
training_epochs = 50
batch_size = 10000
n_features=784
n_classes=10
n_neurons_in_h1 = 500
n_neurons_in_h2 = 500
n_neurons_in_h3 = 500


class NN(object):
    def __init__(self):
        self.graph = tf.Graph()
        with self.graph.as_default():
            # input place holders
            self.X = tf.placeholder(tf.float32, [None, n_features])
            self.Y = tf.placeholder(tf.float32, [None, n_classes])
            self.mode = tf.placeholder(tf.bool)
            self.keep_prob = tf.placeholder(tf.float32)
            
            self.W1 = tf.Variable(tf.truncated_normal([n_features, n_neurons_in_h1], mean=0, stddev=1 / np.sqrt(n_features)), name='weights1')
            self.b1 = tf.Variable(tf.truncated_normal([n_neurons_in_h1],mean=0, stddev=1 / np.sqrt(n_features)), name='biases1')

            self.h1 = tf.matmul(self.X, self.W1)+self.b1
            self.h1=tf.maximum(self.h1,tf.zeros([n_neurons_in_h1], tf.float32))
            
            #network parameters(weights and biases) are set and initialized(Layer2)
            self.W2 = tf.Variable(tf.random_normal([n_neurons_in_h1, n_neurons_in_h2],mean=0,stddev=1/np.sqrt(n_features)),name='weights2')
            self.b2 = tf.Variable(tf.random_normal([n_neurons_in_h2],mean=0,stddev=1/np.sqrt(n_features)),name='biases2')

            self.h2 = tf.matmul(self.h1, self.W2)+self.b2
            self.h2=tf.maximum(self.h2,tf.zeros([n_neurons_in_h2], tf.float32))
            
            #network parameters(weights and biases) are set and initialized(Layer3)
            self.W3 = tf.Variable(tf.random_normal([n_neurons_in_h2, n_neurons_in_h3],mean=0,stddev=1/np.sqrt(n_features)),name='weights3')
            self.b3 = tf.Variable(tf.random_normal([n_neurons_in_h3],mean=0,stddev=1/np.sqrt(n_features)),name='biases3')

            self.h3 = tf.matmul(self.h2, self.W3)+self.b3
            self.h3=tf.maximum(self.h3,tf.zeros([n_neurons_in_h3], tf.float32))
            
            """self.h1 = tf.layers.dense(inputs=self.X, units=500)
            self.h1 = tf.layers.batch_normalization(self.h1, training=self.mode)
            self.h1 = tf.nn.relu(self.h1)
            self.h1 = tf.nn.dropout(self.h1, self.keep_prob)
            self.h2 = tf.layers.dense(inputs=self.h1, units=500)
            self.h2 = tf.layers.batch_normalization(self.h2, training=self.mode)
            self.h2 = tf.nn.relu(self.h2)
            self.h2 = tf.nn.dropout(self.h2, self.keep_prob)
            self.h3 = tf.layers.dense(inputs=self.h2, units=500)
            self.h3 = tf.layers.batch_normalization(self.h3, training=self.mode)
            self.h3 = tf.nn.relu(self.h3)
            self.h3 = tf.nn.dropout(self.h3, self.keep_prob)
            """

            self.logits = tf.layers.dense(inputs=self.h3, units=10)
            self.logits = tf.layers.batch_normalization(self.logits, training=self.mode)
            self.pred = tf.nn.softmax(self.logits)
            # Test model and check accuracy
            self.correct_prediction = tf.equal(tf.argmax(self.pred, 1), tf.argmax(self.Y, 1))
            self.accuracy = tf.reduce_mean(tf.cast(self.correct_prediction, tf.float32))

            tf.summary.scalar('accuracy', self.accuracy)
            # define cost/loss & optimizer
            self.cost = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(logits=self.logits, labels=self.Y))
            self.global_step = tf.Variable(0, name='global_step', trainable=False)
            tf.summary.scalar('mean_loss', self.cost)
            self.merged = tf.summary.merge_all()

            # When using the batchnormalization layers,
            # it is necessary to manually add the update operations
            # because the moving averages are not included in the graph            
            update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
            with tf.control_dependencies(update_ops):                     
                self.optimizer = tf.train.AdamOptimizer(learning_rate=learning_rate).minimize(self.cost, global_step=self.global_step)

print 'Initialisation done'       


# In[40]:


nn = NN()
# Best validation accuracy seen so far.
best_validation_accuracy = 0.0

# Iteration-number for last improvement to validation accuracy.
last_improvement = 0

# Stop optimization if no improvement found in this many iterations.
patience = 10

# Start session
sv = tf.train.Supervisor(graph=nn.graph,
                         logdir='weights/',
                         summary_op=None,
                         save_model_secs=0)

logistic = linear_model.LogisticRegression(C=1e5)

if mode==1 or mode==2:
    with sv.managed_session(config=tf.ConfigProto(allow_soft_placement=True)) as sess:

        if mode==1:
            print 'Neural Network is getting trained : '
            for epoch in range(training_epochs):
                avg_cost = 0
                total_batch = int(len(train_data) / batch_size)
                if sv.should_stop(): break
                for i in range(total_batch):
                    batch_xs, batch_ys = train_data[(i)*batch_size:(i+1)*batch_size], train_labels[(i)*batch_size:(i+1)*batch_size]
                    feed_dict = {nn.X: batch_xs, nn.Y: batch_ys, nn.mode:True, nn.keep_prob:0.8}
                    c, _ = sess.run([nn.cost, nn.optimizer], feed_dict=feed_dict)
                    avg_cost += c / total_batch
                    #units = sess.run(nn.h1,feed_dict={nn.X:test_data,nn.Y: test_labels, nn.mode:False,nn.keep_prob:1.0})
                    #print units[0]

                    #logistic.fit(batch_xs,np.argmax(batch_ys,1))#labels are test_labels over here
                    if i%50:

                        sv.summary_computed(sess, sess.run(nn.merged, feed_dict))
                        gs = sess.run(nn.global_step, feed_dict)

                print 'Epoch : ' + str(epoch) + ' Training Loss: ' + str(avg_cost)
                acc = sess.run(nn.accuracy, feed_dict={
                                nn.X: val_data, nn.Y: val_labels, nn.mode:False, nn.keep_prob:1.0})
                print 'Validation Accuracy: ' + str(acc*100) + '%'
                if acc > best_validation_accuracy:
                    last_improvement = epoch
                    best_validation_accuracy = acc
                    sv.saver.save(sess, 'weights' + '/model_gs', global_step=gs)
                if epoch - last_improvement > patience:
                    print("Early stopping ...")
                    break

        else:
            acc = sess.run(nn.accuracy, feed_dict={
                                nn.X: test_data, nn.Y: test_labels, nn.mode:False, nn.keep_prob:1.0})
            print 'Test Accuracy: ' + str(acc*100)+ '%'


        print "done"
        #units = sess.run([nn.h3,nn.p],feed_dict={nn.X:train_data[0:1],nn.Y: train_labels[0:1], nn.mode:False,nn.keep_prob:1.0})  
        #print units[0]
        print '--------'

        sess.close()


# In[55]:


#mode=5
batch=60000
tbatch=10000
units=None
if mode==3 or mode==4 or mode==5:
    print 'Training Logistic Regression'
if mode==3:
    with sv.managed_session(config=tf.ConfigProto(allow_soft_placement=True)) as sess:
        units = sess.run(nn.h1,feed_dict={nn.X:train_data[0:batch],nn.Y: train_labels[0:batch], nn.mode:False,nn.keep_prob:1.0})  
        logistic.fit(units,np.argmax(train_labels[0:batch],1))#labels are test_labels over here
        print 'Logistic Regression Trained'
        units = sess.run(nn.h1,feed_dict={nn.X:test_data[0:tbatch],nn.Y: test_labels[0:tbatch], nn.mode:False,nn.keep_prob:1.0})  
        
        o=logistic.predict(units)
        
        correct= o==np.argmax(test_labels[0:tbatch],1)
        f=correct.astype(int)
        print 'Accuracy : '+ str(np.sum(f)*100/(tbatch+0.0))+ '%'
        print 'Predicted Output of the given batch : '
        print o
        sess.close()
elif mode==4:
    with sv.managed_session(config=tf.ConfigProto(allow_soft_placement=True)) as sess:
        units = sess.run(nn.h2,feed_dict={nn.X:train_data[0:batch],nn.Y: train_labels[0:batch], nn.mode:False,nn.keep_prob:1.0})  
        logistic.fit(units,np.argmax(train_labels[0:batch],1))#labels are test_labels over here
        print 'Logistic Regression Trained'
        units = sess.run(nn.h2,feed_dict={nn.X:test_data[0:tbatch],nn.Y: test_labels[0:tbatch], nn.mode:False,nn.keep_prob:1.0})  
        o=logistic.predict(units)
        
        correct= o==np.argmax(test_labels[0:tbatch],1)
        f=correct.astype(int)
        print 'Accuracy : '+ str(np.sum(f)*100/(tbatch+0.0))+ '%'
        print 'Predicted Output of the given batch : '
        print o
        #print np.argmax(test_labels[0:tbatch],1)
        sess.close()
elif mode==5:
    with sv.managed_session(config=tf.ConfigProto(allow_soft_placement=True)) as sess:
        units = sess.run(nn.h3,feed_dict={nn.X:train_data[0:batch],nn.Y: train_labels[0:batch], nn.mode:False,nn.keep_prob:1.0})  
        logistic.fit(units,np.argmax(train_labels[0:batch],1))#labels are test_labels over here
        print 'Logistic Regression Trained'
        units = sess.run(nn.h3,feed_dict={nn.X:test_data[0:tbatch],nn.Y: test_labels[0:tbatch], nn.mode:False,nn.keep_prob:1.0})  
        o=logistic.predict(units)
        
        correct= o==np.argmax(test_labels[0:tbatch],1)
        f=correct.astype(int)
        print 'Accuracy : '+ str(np.sum(f)*100/(tbatch+0.0)) + '%'
        print 'Predicted Output of the given batch : '
        print o
        #print np.argmax(test_labels[0:tbatch],1)
        sess.close()


# In[6]:




